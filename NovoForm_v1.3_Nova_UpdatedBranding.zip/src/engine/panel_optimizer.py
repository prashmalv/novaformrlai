"""
Panel Optimization Engine  — Phase 2.

Supported element types:
  Column      : 4 faces, OC80 at 4 corners
  Wall        : 2 faces, OC80 at 4 end corners
  Shear Wall  : same as Wall
  Box Culvert : 4 inner faces (L × H × 2  +  W × H × 2), IC100 at all 4 inner corners
  Drain       : 3 inner faces (L × H × 2  +  W × H × 1 base), IC100 at 2 bottom corners
  Monolithic  : treated as column for each column stub; walls handled separately

Complex wall junctions (T / L / C):
  L-shape : 1 extra IC100 at junction per row
  T-shape : 2 extra IC100 at junction per row
  C-shape : 2 extra IC100 at junction per row (enclosed ends use OC)
"""
import json
import os
from typing import Optional
from src.models.element import (
    StructuralElement, ElementType, JunctionType, PanelEntry, ElementBOQ
)

# Load config
_cfg_path = os.path.join(os.path.dirname(__file__), '../../config/panel_config.json')
with open(_cfg_path) as f:
    _CFG = json.load(f)

STANDARD_WIDTHS: list[int]  = _CFG['panel_system']['standard_widths_mm']
STANDARD_HEIGHTS: list[int] = _CFG['panel_system']['standard_heights_mm']
OC_WIDTH:   int = _CFG['panel_system']['oc_width_mm']
IC_WIDTH:   int = _CFG['panel_system']['ic_width_mm']
MAX_SPACER: int = _CFG['panel_system']['max_spacer_mm']

# Frozensets for O(1) catalog lookup
_CATALOG_WIDTHS_SET:   frozenset = frozenset(STANDARD_WIDTHS)
_CATALOG_HEIGHTS_SET:  frozenset = frozenset(STANDARD_HEIGHTS)


def is_catalog_panel(panel) -> bool:
    """
    Return True if this PanelEntry exists in Nova's standard product catalog.
    Rules:
    - Height must be a catalog standard height (1235 / 2470 / 3705mm).
    - OC and IC at any standard height are always catalog items.
    - Flat panels must have a catalog width AND a catalog height.
    """
    h = int(round(panel.height_mm))
    w = int(round(panel.width_mm))
    if h not in _CATALOG_HEIGHTS_SET:
        return False
    if panel.is_corner or panel.is_inner_corner:
        return True        # OC80 / IC100 at any standard height ✓
    return w in _CATALOG_WIDTHS_SET


def find_panel_combination(
    target_mm: float,
    available_widths: list[int] = None,
    max_panels: int = 10,
) -> tuple[list[int], float]:
    """
    Find optimal panel widths combination for a given face dimension.

    Returns:
        (list of panel widths used, spacer_mm)
        spacer_mm > 0 means panels don't fully cover target (gap = spacer)
        spacer_mm < 0 means panels overshoot by abs(spacer_mm)
    """
    if available_widths is None:
        available_widths = STANDARD_WIDTHS

    # Sort descending for greedy preference
    widths = sorted(available_widths, reverse=True)
    target = int(round(target_mm))

    # Try exact match using DP (subset sum with repetition allowed)
    result = _dp_exact(target, widths, max_panels)
    if result is not None:
        return result, 0.0

    # Try with spacer: find combo that covers (target - spacer) exactly
    for spacer in range(1, MAX_SPACER + 1):
        reduced = target - spacer
        if reduced <= 0:
            break
        result = _dp_exact(reduced, widths, max_panels)
        if result is not None:
            return result, float(spacer)

    # Fallback: greedy (may overshoot slightly)
    combo, overshoot = _greedy_fit(target, widths)
    return combo, -float(overshoot)  # negative = overshoot


def _combo_score(combo: list[int]) -> tuple:
    """
    Score a panel combination — lower tuple value is BETTER.

    Priority derived from actual Nova Formworks quotations:
      1. Avoid highly unbalanced splits where the smallest panel is
         less than 1/3 of the largest (e.g. [350,100] for 450mm is bad).
      2. Fewest total panels (fewer handling pieces on site).
      3a. Prefer symmetric splits (all panels equal width) — e.g. [500,500].
      3b. Otherwise prefer largest maximum panel — e.g. [600,300] over [500,400].
         This matches Nova's practice: 900mm → [600,300], 1000mm → [500,500].
    """
    max_p = max(combo)
    min_p = min(combo)
    ugly  = 1 if min_p * 3 < max_p else 0  # 1 = unbalanced split
    symmetric = 0 if min_p == max_p else 1  # 0 = all equal (preferred)
    return (ugly, len(combo), symmetric, -max_p)


def _dp_exact(target: int, widths: list[int], max_panels: int) -> Optional[list[int]]:
    """
    DP to find panel combination summing exactly to target.
    Scoring: see _combo_score — prefer balanced splits, then fewer panels.
    """
    if target <= 0:
        return []

    dp = [None] * (target + 1)
    dp[0] = []

    for s in range(1, target + 1):
        best = None
        for w in widths:
            if w > s:
                continue
            prev = dp[s - w]
            if prev is None:
                continue
            candidate = prev + [w]
            if len(candidate) > max_panels:
                continue
            if best is None or _combo_score(candidate) < _combo_score(best):
                best = candidate
        dp[s] = best

    return dp[target]


def _greedy_fit(target: int, widths: list[int]) -> tuple[list[int], int]:
    """Greedy: keep adding panels until target covered. May overshoot."""
    combo = []
    remaining = target
    while remaining > 0:
        placed = False
        for w in widths:
            if w <= remaining:
                combo.append(w)
                remaining -= w
                placed = True
                break
        if not placed:
            # Must overshoot with smallest available panel
            smallest = min(widths)
            combo.append(smallest)
            remaining -= smallest
    overshoot = -remaining if remaining < 0 else 0
    return combo, overshoot


def _count_panels(combo: list[int]) -> dict[int, int]:
    """Count panel widths → {width: count}"""
    counts: dict[int, int] = {}
    for w in combo:
        counts[w] = counts.get(w, 0) + 1
    return counts


def optimize_column(element: StructuralElement, panel_height_mm: float) -> ElementBOQ:
    """
    Compute formwork BOQ for a rectangular column.

    Column has 4 faces:
      - 2 faces of length_mm (front/back)
      - 2 faces of width_mm (sides)
    OC80 panels at all 4 corners.
    """
    boq = ElementBOQ(element=element)
    warnings = []

    panel_h = int(round(panel_height_mm))

    # Determine stacking: how many rows of panels needed for height
    # height_mm may need to be covered by stacked panels
    h = element.height_mm
    rows = max(1, int(h / panel_h))
    if rows * panel_h < h:
        remaining_h = h - rows * panel_h
        # Allow slight overshoot or flag warning
        warnings.append(
            f"Height {h}mm not evenly divisible by panel height {panel_h}mm. "
            f"Using {rows} rows ({rows * panel_h}mm). Gap = {h - rows * panel_h}mm."
        )

    achieved_height = rows * panel_h
    boq.height_note = f"{achieved_height}MM"

    # --- LENGTH faces (2 faces, each length_mm wide) ---
    len_combo, len_spacer = find_panel_combination(element.length_mm)
    if len_spacer > 0:
        warnings.append(f"Length face {element.length_mm}mm: spacer of {len_spacer}mm needed.")
    elif len_spacer < 0:
        warnings.append(f"Length face {element.length_mm}mm: overshoot of {-len_spacer}mm.")

    # --- WIDTH faces (2 faces, each width_mm wide) ---
    wid_combo, wid_spacer = find_panel_combination(element.width_mm)
    if wid_spacer > 0:
        warnings.append(f"Width face {element.width_mm}mm: spacer of {wid_spacer}mm needed.")
    elif wid_spacer < 0:
        warnings.append(f"Width face {element.width_mm}mm: overshoot of {-wid_spacer}mm.")

    # Collect all panels
    panel_counts: dict[str, dict] = {}

    def _add_panels(combo: list[int], face_count: int, label_prefix=""):
        # face_count = number of identical faces (2 for columns)
        # rows = vertical stacking rows
        total_multiplier = face_count * rows
        counts = _count_panels(combo)
        for width, cnt in counts.items():
            key = f"{width}X{panel_h}"
            total_qty = cnt * total_multiplier
            if key in panel_counts:
                panel_counts[key]['qty'] += total_qty
            else:
                panel_counts[key] = {
                    'width': width, 'height': panel_h,
                    'qty': total_qty, 'is_corner': False
                }

    _add_panels(len_combo, face_count=2)
    _add_panels(wid_combo, face_count=2)

    # OC (Outer Corner): 4 corners × rows
    oc_key = f"OC{OC_WIDTH}X{panel_h}"
    panel_counts[oc_key] = {
        'width': OC_WIDTH, 'height': panel_h,
        'qty': 4 * rows, 'is_corner': True
    }

    # Build PanelEntry list (OC first, then flat panels sorted by width desc)
    oc_entry = PanelEntry(
        size_label=oc_key,
        width_mm=OC_WIDTH, height_mm=panel_h,
        quantity=panel_counts[oc_key]['qty'],
        is_corner=True
    )
    boq.panels = [oc_entry]

    flat_keys = sorted(
        [k for k in panel_counts if k != oc_key],
        key=lambda k: panel_counts[k]['width'],
        reverse=True
    )
    for k in flat_keys:
        d = panel_counts[k]
        boq.panels.append(PanelEntry(
            size_label=k,
            width_mm=d['width'], height_mm=d['height'],
            quantity=d['qty']
        ))

    boq.spacer_mm = max(len_spacer, wid_spacer)
    boq.warnings = warnings
    return boq


def optimize_wall(element: StructuralElement, panel_height_mm: float) -> ElementBOQ:
    """
    Compute formwork BOQ for a straight or junction wall.

    Straight wall : 2 faces × length_mm, OC80 at 4 end corners.
    L-junction    : add 1 IC100 per row at the inner corner.
    T-junction    : add 2 IC100 per row at both inner corners.
    C-junction    : add 2 IC100 per row; enclosed end uses OC like a column end.
    """
    boq = ElementBOQ(element=element)
    warnings = []
    panel_h = int(round(panel_height_mm))

    h = element.height_mm
    rows = max(1, int(h / panel_h))
    if rows * panel_h < h:
        warnings.append(
            f"Height {h}mm: {rows} rows give {rows * panel_h}mm. "
            f"Difference {h - rows * panel_h}mm."
        )
    achieved_height = rows * panel_h
    boq.height_note = f"{achieved_height}MM"

    combo, spacer = find_panel_combination(element.length_mm)
    if spacer > 0:
        warnings.append(f"Wall face {element.length_mm}mm: spacer {spacer}mm.")
    elif spacer < 0:
        warnings.append(f"Wall face {element.length_mm}mm: overshoot {-spacer}mm.")

    panel_counts: dict[str, dict] = {}

    # Flat panels — 2 main faces
    counts = _count_panels(combo)
    for width, cnt in counts.items():
        key = f"{width}X{panel_h}"
        total_qty = cnt * 2 * rows
        panel_counts[key] = {'width': width, 'height': panel_h,
                              'qty': total_qty, 'is_corner': False}

    # --- OC corners at straight ends ---
    jt = getattr(element, 'junction_type', JunctionType.NONE)

    # Straight wall: 4 OC (2 ends × 2 faces)
    # C-shape: only 2 OC at the open end; enclosed end gets OC too = 4 total
    oc_qty = 4 * rows
    oc_key = f"OC{OC_WIDTH}X{panel_h}"
    panel_counts[oc_key] = {'width': OC_WIDTH, 'height': panel_h,
                             'qty': oc_qty, 'is_corner': True}

    # --- IC corners at junctions ---
    ic_qty = 0
    if jt == JunctionType.L:
        ic_qty = 2 * rows        # 1 junction × 2 faces
        warnings.append("L-shaped junction: IC100 panels added at inner corner.")
    elif jt == JunctionType.T:
        ic_qty = 4 * rows        # 2 junctions × 2 faces
        warnings.append("T-shaped junction: IC100 panels added at both inner corners.")
    elif jt == JunctionType.C:
        ic_qty = 4 * rows        # 2 inner corners of C-shape
        warnings.append("C/U-shaped wall: IC100 panels added at both inner corners.")

    ic_key = f"IC{IC_WIDTH}X{panel_h}"
    if ic_qty > 0:
        panel_counts[ic_key] = {'width': IC_WIDTH, 'height': panel_h,
                                 'qty': ic_qty, 'is_corner': True,
                                 'is_inner': True}

    # Build PanelEntry list: IC first, then OC, then flat panels
    boq.panels = []
    if ic_key in panel_counts:
        d = panel_counts[ic_key]
        boq.panels.append(PanelEntry(
            size_label=ic_key, width_mm=IC_WIDTH, height_mm=panel_h,
            quantity=d['qty'], is_corner=True, is_inner_corner=True
        ))

    boq.panels.append(PanelEntry(
        size_label=oc_key, width_mm=OC_WIDTH, height_mm=panel_h,
        quantity=panel_counts[oc_key]['qty'], is_corner=True
    ))

    flat_keys = sorted(
        [k for k in panel_counts if k not in (oc_key, ic_key)],
        key=lambda k: panel_counts[k]['width'], reverse=True
    )
    for k in flat_keys:
        d = panel_counts[k]
        boq.panels.append(PanelEntry(
            size_label=k, width_mm=d['width'], height_mm=d['height'], quantity=d['qty']
        ))

    boq.spacer_mm = max(spacer, 0)
    boq.warnings = warnings
    return boq


def optimize_box_culvert(element: StructuralElement, panel_height_mm: float) -> ElementBOQ:
    """
    Box Culvert formwork BOQ.

    A box culvert is a rectangular tunnel/conduit. The formwork covers:
      - 2 side walls  : each length_mm × height_mm
      - 1 soffit slab : length_mm wide (top inner face, if cast in-situ)
      - 2 end walls   : each width_mm × height_mm
    Inner corners between walls and soffit use IC100 panels.
    Outer corners use OC80.

    element.length_mm = inner clear length (span)
    element.width_mm  = inner clear width (span)
    element.height_mm = wall height / casting height
    """
    boq = ElementBOQ(element=element)
    warnings = []
    panel_h = int(round(panel_height_mm))

    h = element.height_mm
    rows = max(1, int(h / panel_h))
    if rows * panel_h < h:
        warnings.append(
            f"Culvert height {h}mm: {rows} rows = {rows*panel_h}mm. "
            f"Gap {h - rows*panel_h}mm."
        )
    boq.height_note = f"{rows * panel_h}MM"

    panel_counts: dict[str, dict] = {}

    def _add(combo, face_count):
        for width, cnt in _count_panels(combo).items():
            key = f"{width}X{panel_h}"
            qty = cnt * face_count * rows
            if key in panel_counts:
                panel_counts[key]['qty'] += qty
            else:
                panel_counts[key] = {'width': width, 'height': panel_h,
                                     'qty': qty, 'is_corner': False}

    # Side walls × 2 (left & right inner faces — length direction)
    l_combo, l_sp = find_panel_combination(element.length_mm)
    if l_sp > 0: warnings.append(f"Culvert length {element.length_mm}mm: spacer {l_sp}mm.")
    _add(l_combo, 2)

    # End walls × 2 (width direction inner faces)
    w_combo, w_sp = find_panel_combination(element.width_mm)
    if w_sp > 0: warnings.append(f"Culvert width {element.width_mm}mm: spacer {w_sp}mm.")
    _add(w_combo, 2)

    # IC100 at all 4 inner vertical corners × rows
    ic_key = f"IC{IC_WIDTH}X{panel_h}"
    panel_counts[ic_key] = {'width': IC_WIDTH, 'height': panel_h,
                             'qty': 4 * rows, 'is_corner': True, 'is_inner': True}

    # OC80 at outer top corners (where walls meet soffit) × 2 per end × rows
    oc_key = f"OC{OC_WIDTH}X{panel_h}"
    panel_counts[oc_key] = {'width': OC_WIDTH, 'height': panel_h,
                             'qty': 4 * rows, 'is_corner': True}

    # Build panel list: IC → OC → flat
    boq.panels = []
    boq.panels.append(PanelEntry(
        size_label=ic_key, width_mm=IC_WIDTH, height_mm=panel_h,
        quantity=panel_counts[ic_key]['qty'], is_corner=True, is_inner_corner=True
    ))
    boq.panels.append(PanelEntry(
        size_label=oc_key, width_mm=OC_WIDTH, height_mm=panel_h,
        quantity=panel_counts[oc_key]['qty'], is_corner=True
    ))
    for k in sorted([k for k in panel_counts if k not in (oc_key, ic_key)],
                    key=lambda k: panel_counts[k]['width'], reverse=True):
        d = panel_counts[k]
        boq.panels.append(PanelEntry(
            size_label=k, width_mm=d['width'], height_mm=d['height'], quantity=d['qty']
        ))

    boq.spacer_mm = max(l_sp, w_sp, 0)
    boq.warnings = warnings
    warnings.append("Box Culvert: verify soffit (top slab) formwork with engineer.")
    return boq


def optimize_drain(element: StructuralElement, panel_height_mm: float) -> ElementBOQ:
    """
    U-shaped Drain (open-top) formwork BOQ.

    3 inner faces:
      - 2 side walls : length_mm × height_mm each
      - 1 base       : width_mm × height_mm (bottom inner face, if used)
    IC100 at 2 bottom inner corners.
    OC80 at 4 top outer corners.

    element.length_mm = drain length
    element.width_mm  = inner clear width
    element.height_mm = drain wall height
    """
    boq = ElementBOQ(element=element)
    warnings = []
    panel_h = int(round(panel_height_mm))

    h = element.height_mm
    rows = max(1, int(h / panel_h))
    if rows * panel_h < h:
        warnings.append(f"Drain height {h}mm: {rows} rows = {rows*panel_h}mm.")
    boq.height_note = f"{rows * panel_h}MM"

    panel_counts: dict[str, dict] = {}

    def _add(combo, face_count):
        for width, cnt in _count_panels(combo).items():
            key = f"{width}X{panel_h}"
            qty = cnt * face_count * rows
            if key in panel_counts:
                panel_counts[key]['qty'] += qty
            else:
                panel_counts[key] = {'width': width, 'height': panel_h,
                                     'qty': qty, 'is_corner': False}

    l_combo, l_sp = find_panel_combination(element.length_mm)
    if l_sp > 0: warnings.append(f"Drain length {element.length_mm}mm: spacer {l_sp}mm.")
    _add(l_combo, 2)   # 2 side walls

    w_combo, w_sp = find_panel_combination(element.width_mm)
    if w_sp > 0: warnings.append(f"Drain width {element.width_mm}mm: spacer {w_sp}mm.")
    _add(w_combo, 1)   # 1 base (bottom inner face)

    # IC100 at 2 bottom inner corners × rows
    ic_key = f"IC{IC_WIDTH}X{panel_h}"
    panel_counts[ic_key] = {'width': IC_WIDTH, 'height': panel_h,
                             'qty': 2 * rows, 'is_corner': True, 'is_inner': True}

    # OC80 at 4 top outer corners × rows
    oc_key = f"OC{OC_WIDTH}X{panel_h}"
    panel_counts[oc_key] = {'width': OC_WIDTH, 'height': panel_h,
                             'qty': 4 * rows, 'is_corner': True}

    boq.panels = []
    boq.panels.append(PanelEntry(
        size_label=ic_key, width_mm=IC_WIDTH, height_mm=panel_h,
        quantity=panel_counts[ic_key]['qty'], is_corner=True, is_inner_corner=True
    ))
    boq.panels.append(PanelEntry(
        size_label=oc_key, width_mm=OC_WIDTH, height_mm=panel_h,
        quantity=panel_counts[oc_key]['qty'], is_corner=True
    ))
    for k in sorted([k for k in panel_counts if k not in (oc_key, ic_key)],
                    key=lambda k: panel_counts[k]['width'], reverse=True):
        d = panel_counts[k]
        boq.panels.append(PanelEntry(
            size_label=k, width_mm=d['width'], height_mm=d['height'], quantity=d['qty']
        ))

    boq.spacer_mm = max(l_sp, w_sp, 0)
    boq.warnings = warnings
    warnings.append("Drain: confirm whether base slab formwork is required on site.")
    return boq


IC_75_WIDTH: int = 75   # supplementary inner-corner panel used in beam-slab junctions


def optimize_beam_bottom(element: StructuralElement, panel_height_mm: float) -> ElementBOQ:
    """
    Beam Bottom formwork BOQ.

    The bottom shutter sits beneath the beam and consists of:
      - 1 flat panel whose width ≥ beam internal clear width (element.width_mm)
      - 2 OC80 panels locking the sides (one each end of the flat panel)
    This assembly is expressed as: (OC+{flat_w}+OC)X{height_mm}

    element.width_mm  = beam internal clear width  (selects flat panel size)
    element.height_mm = beam depth / shuttering height  (= assembly height)
    element.length_mm = beam span (informational; not used for panel count)
    element.quantity  = number of beam bottom sets
    """
    boq = ElementBOQ(element=element)
    warnings: list[str] = []

    depth = int(round(element.height_mm))   # beam depth = panel height for this assembly
    beam_w = element.width_mm               # internal clear width

    # Find the nearest standard flat panel width ≥ beam_w
    flat_w = next((w for w in sorted(STANDARD_WIDTHS) if w >= beam_w), max(STANDARD_WIDTHS))
    if flat_w > beam_w:
        warnings.append(
            f"Beam width {beam_w:.0f}mm: using nearest standard panel {flat_w}mm "
            f"(overshoot {flat_w - beam_w:.0f}mm)."
        )

    # Panel label format: (OC+{flat_w}+OC)X{depth}
    label = f"(OC+{flat_w}+OC)X{depth}"

    # area = (OC_width + flat_w + OC_width) × depth
    total_w_mm = OC_WIDTH + flat_w + OC_WIDTH
    area_sqm = round(total_w_mm * depth / 1_000_000, 6)

    boq.panels = [
        PanelEntry(
            size_label=label,
            width_mm=total_w_mm,
            height_mm=depth,
            quantity=element.quantity,
            area_sqm=area_sqm,
        )
    ]
    boq.height_note = f"{depth}MM"
    boq.warnings = warnings
    return boq


def optimize_beam_side(element: StructuralElement, panel_height_mm: float) -> ElementBOQ:
    """
    Beam Side & Slab formwork BOQ.

    Covers the two vertical side faces of a beam plus the slab soffit panels at
    the beam-slab junction.

    element.height_mm = beam side height (depth of the beam side face)
    element.length_mm = beam span (determines how many panels along the side)
    element.width_mm  = beam wall thickness (used for accessories; not for panel count)
    element.quantity  = number of beam side sets

    Panels per side:
      - IC100 × 1 at each end of the beam side (beam-slab junction corner)
      - Flat panels covering (length_mm − 2×IC100_width) span
    Both sides (× 2).
    """
    boq = ElementBOQ(element=element)
    warnings: list[str] = []

    beam_h  = int(round(element.height_mm))   # beam side height
    beam_L  = element.length_mm               # beam span

    # IC100 occupies IC_WIDTH mm at each end of both sides
    ic_used = IC_WIDTH * 2
    flat_span = max(0.0, beam_L - ic_used)

    # Flat panel combination for the remaining span
    if flat_span > 0:
        combo, spacer = find_panel_combination(flat_span)
        if spacer > 0:
            warnings.append(f"Beam side span {flat_span:.0f}mm: spacer {spacer:.0f}mm needed.")
    else:
        combo, spacer = [], 0.0

    panel_counts: dict[str, dict] = {}

    # IC100 at 2 ends × 2 sides
    ic_key = f"IC{IC_WIDTH}X{beam_h}"
    panel_counts[ic_key] = {
        'width': IC_WIDTH, 'height': beam_h,
        'qty': 4 * element.quantity, 'is_corner': True, 'is_inner': True
    }

    # Flat panels × 2 sides
    for w, cnt in _count_panels(combo).items():
        key = f"{w}X{beam_h}"
        qty = cnt * 2 * element.quantity
        if key in panel_counts:
            panel_counts[key]['qty'] += qty
        else:
            panel_counts[key] = {'width': w, 'height': beam_h,
                                  'qty': qty, 'is_corner': False}

    boq.panels = []
    boq.panels.append(PanelEntry(
        size_label=ic_key, width_mm=IC_WIDTH, height_mm=beam_h,
        quantity=panel_counts[ic_key]['qty'], is_corner=True, is_inner_corner=True
    ))
    for k in sorted([k for k in panel_counts if k != ic_key],
                    key=lambda k: panel_counts[k]['width'], reverse=True):
        d = panel_counts[k]
        boq.panels.append(PanelEntry(
            size_label=k, width_mm=d['width'], height_mm=d['height'], quantity=d['qty']
        ))

    boq.height_note = f"{beam_h}MM"
    boq.spacer_mm = spacer
    boq.warnings = warnings
    warnings.append(
        f"Beam Side: IC100 at 2 ends per side. "
        f"Flat panels cover {flat_span:.0f}mm span × 2 sides."
    )
    return boq


def compute_boq(element: StructuralElement, panel_height_mm: float = 3200) -> ElementBOQ:
    """Main entry: compute BOQ for any element type."""
    if element.is_column or element.is_monolithic:
        return optimize_column(element, panel_height_mm)
    elif element.is_wall:
        return optimize_wall(element, panel_height_mm)
    elif element.is_box_culvert:
        return optimize_box_culvert(element, panel_height_mm)
    elif element.is_drain:
        return optimize_drain(element, panel_height_mm)
    elif element.is_beam_bottom:
        return optimize_beam_bottom(element, panel_height_mm)
    elif element.is_beam_side:
        return optimize_beam_side(element, panel_height_mm)
    else:
        raise NotImplementedError(f"Element type {element.element_type} not yet supported.")
